﻿My Yard Our Message Template Readme
------------------------------------------------------------------------
In this folder you will find three template files: a file for
illustrator, photoshop and an all-purpose jpeg. Please use which ever
file works for your application and design process. Designs must be
submitted as a flattened RGB jpeg image with pixel dimensions of 4200px
by 2800px. Other sizes will be rejected.

Your artwork should cover the entire template. Your design will appear
on both sides of the sign, it is not possible to create a two-sided
sign. When printed, there will be a 1/2" white border around the edge.

Your design must incorporate The UnConvention URL (TheUnConvention.com)
and My Yard Our Message URL (MyYardOurMessage.com) in some fashion. Both
are provided in the template files, but you are not required to use the
provided color, typeface, or size. The URLs should be generally readable
from four feet away.

When you're done, submit your sign at:
http://myyardourmessage.com/submit/


Template Specs
------------------------------------------------------------------------
21" wide (4200 px at 200 dpi) 
14" tall (2800 px at 200 dpi) 
RGB Color (Not CMYK)


Submission Guidelines
------------------------------------------------------------------------
Yard sign designs should be thoughtful, creative, and avoid
hateful and defamatory language or images. The project sponsors value
non-partisan participation and reserve the right to reject designs that
are unlawful, harmful, threatening, abusive, harassing, tortuous,
defamatory, vulgar, obscene, libelous, invasive of another's privacy,
hateful, or racially, ethnically or otherwise objectionable to a
reasonable person.

When you submit your work, you must agree to the Terms of Service listed
on the submission page and agree tho license your work under the
Creative Commons Non-Commercial Share-Alike License. For more details:
http://creativecommons.org/licenses/by-nc-sa/3.0/us/


Questions?
------------------------------------------------------------------------
Email help@myyardourmessage.com if you have any questions or
problems.